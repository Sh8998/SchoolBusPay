import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../models/driver.dart';
import '../../models/parent.dart';
import '../../models/payment.dart';
import '../../providers/app_state.dart';
import 'driver/add_parent_screen.dart';
import 'driver/payment_records_screen.dart';


class DriverDashboard extends ConsumerStatefulWidget {
  const DriverDashboard({super.key});

  @override
  ConsumerState<DriverDashboard> createState() => _DriverDashboardState();
}

class _DriverDashboardState extends ConsumerState<DriverDashboard> {
  @override
  Widget build(BuildContext context) {
    ref.invalidate(firstDriverProvider);
    final driverAsync = ref.watch(firstDriverProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Driver Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: _showRemindersDialog,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
      body: driverAsync.when(
        data: (driver) {
          if (driver == null) return _buildNoDriverUI(context, ref);
          
          return Column(
            children: [
              // Driver Info Card
              Container(
                padding: const EdgeInsets.all(20),
                color: Theme.of(context).colorScheme.primaryContainer,
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      child: const Icon(Icons.drive_eta, size: 30, color: Colors.white),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Welcome, ${driver.name}',
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          Text(
                            'Bus No: ${driver.busNo}',
                            style: Theme.of(context).textTheme.bodyLarge,
                          ),
                          Text(
                            'Mobile: ${driver.mobileNumber}',
                            style: Theme.of(context).textTheme.bodyLarge,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              
              // Tab Bar
              DefaultTabController(
                length: 2,
                child: Expanded(
                  child: Column(
                    children: [
                      const TabBar(
                        tabs: [
                          Tab(icon: Icon(Icons.payment), text: 'Payments'),
                          Tab(icon: Icon(Icons.people), text: 'Parents'),
                        ],
                      ),
                      Expanded(
                        child: TabBarView(
                          children: [
                            _buildPaymentsTab(context, ref, driver),
                            _buildParentsTab(context, ref, driver),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(child: Text('Error: $error')),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          final driver = ref.read(firstDriverProvider).value;
          if (driver != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AddParentScreen(driver: driver),
              ),
            );
          }
        },
        child: const Icon(Icons.person_add),
      ),
    );
  }

  Widget _buildPaymentsTab(BuildContext context, WidgetRef ref, Driver driver) {
    final parentsAsync = ref.watch(parentsByDriverProvider(driver.id));
    
    return parentsAsync.when(
      data: (parents) {
        if (parents.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.people_outline, size: 64, color: Colors.grey),
                const SizedBox(height: 16),
                const Text('No parents assigned to your bus'),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AddParentScreen(driver: driver),
                      ),
                    );
                  },
                  child: const Text('Add Parent'),
                ),
              ],
            ),
          );
        }
        
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: parents.length,
          itemBuilder: (context, index) {
            final parent = parents[index];
            return _buildParentPaymentCard(context, ref, parent);
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }

  Widget _buildParentPaymentCard(BuildContext context, WidgetRef ref, Parent parent) {
    final paymentsAsync = ref.watch(paymentsByParentProvider(parent.id));
    
    return paymentsAsync.when(
      data: (payments) {
        final currentMonthPayment = payments.firstWhere(
          (p) => p.month == DateTime.now().month && p.year == DateTime.now().year,
          orElse: () => Payment(
            id: 0,
            parentId: parent.id,
            month: DateTime.now().month,
            year: DateTime.now().year,
            amount: 0,
            isPaid: false,
            dueDate: DateTime.now().toIso8601String(),
          ),
        );

        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: Column(
            children: [
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Theme.of(context).colorScheme.secondary,
                  child: const Icon(Icons.person, color: Colors.white),
                ),
                title: Text(parent.name),
                subtitle: Text('Mobile: ${parent.mobileNumber}'),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Divider(),
                    Text(
                      'Current Month Payment',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Amount: ₹${currentMonthPayment.amount}'),
                        Text('Due: ${DateFormat('dd MMM').format(DateTime.parse(currentMonthPayment.dueDate))}'),
                      ],
                    ),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: currentMonthPayment.isPaid ? 1.0 : 0.0,
                      backgroundColor: Colors.grey[200],
                      color: currentMonthPayment.isPaid ? Colors.green : Colors.orange,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Status: ${currentMonthPayment.isPaid ? 'Paid' : 'Pending'}',
                          style: TextStyle(
                            color: currentMonthPayment.isPaid ? Colors.green : Colors.orange,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (!currentMonthPayment.isPaid)
                          ElevatedButton.icon(
                            icon: const Icon(Icons.notifications_active),
                            label: const Text('Send Reminder'),
                            onPressed: () => _sendReminder(parent),
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ],
          ),
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }

  Widget _buildParentsTab(BuildContext context, WidgetRef ref, Driver driver) {
    final parentsAsync = ref.watch(parentsByDriverProvider(driver.id));
    
    return parentsAsync.when(
      data: (parents) {
        if (parents.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.people_outline, size: 64, color: Colors.grey),
                const SizedBox(height: 16),
                const Text('No parents assigned to your bus'),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AddParentScreen(driver: driver),
                      ),
                    );
                  },
                  child: const Text('Add Parent'),
                ),
              ],
            ),
          );
        }
        
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: parents.length,
          itemBuilder: (context, index) {
            final parent = parents[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 16),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Theme.of(context).colorScheme.secondary,
                  child: const Icon(Icons.person, color: Colors.white),
                ),
                title: Text(parent.name),
                subtitle: Text(parent.mobileNumber),
                trailing: IconButton(
                  icon: const Icon(Icons.phone),
                  onPressed: () => _callParent(parent.mobileNumber),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PaymentRecordsScreen(driver: driver),
                    ),
                  );
                },
              ),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Error: $error')),
    );
  }

  Future<void> _sendReminder(Parent parent) async {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Reminder sent to ${parent.name}'),
        backgroundColor: Colors.green,
      ),
    );
  }

  Future<void> _callParent(String mobileNumber) async {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Calling $mobileNumber'),
      ),
    );
  }

  Future<void> _showRemindersDialog() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Send Reminders'),
        content: const Text('Send payment reminders to all parents with pending fees?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Reminders sent to all parents with pending fees'),
                  backgroundColor: Colors.green,
                ),
              );
            },
            child: const Text('Send All'),
          ),
        ],
      ),
    );
  }

  Widget _buildNoDriverUI(BuildContext context, WidgetRef ref) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, size: 64, color: Colors.grey),
          const SizedBox(height: 16),
          const Text(
            'No driver records found',
            style: TextStyle(fontSize: 18),
          ),
          const SizedBox(height: 8),
          const Text(
            'Please contact admin to set up your account',
            style: TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () {
              ref.invalidate(firstDriverProvider);
            },
            icon: const Icon(Icons.refresh),
            label: const Text('Refresh'),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Go Back'),
          ),
        ],
      ),
    );
  }
}