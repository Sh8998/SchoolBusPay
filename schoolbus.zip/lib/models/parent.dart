class Parent {
  final int id;
  final String name;
  final String mobileNumber;
  final int driverId; // starts as 0 (unassigned)
  final int noOfChildren; // default 1
  final int pendingFees; // default 0
  final List<int> paymentIds;

  Parent({
    required this.id,
    required this.name,
    required this.mobileNumber,
    this.driverId = 0,
    this.noOfChildren = 1,
    this.pendingFees = 0,
    this.paymentIds = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != 0) 'id': id,
      'name': name,
      'mobileNumber': mobileNumber,
      'driverId': driverId,
      'noOfChildren': noOfChildren,
      'pendingFees': pendingFees,
      'paymentIds': paymentIds.join(','), // SQLite-compatible
    };
  }

  factory Parent.fromMap(Map<String, dynamic> map) {
    final paymentIdsStr = (map['paymentIds'] ?? '').toString();
    final parsedPaymentIds = paymentIdsStr.isNotEmpty
        ? paymentIdsStr.split(',').map((e) => int.tryParse(e) ?? 0).toList()
        : [];

    return Parent(
      id: map['id'] as int? ?? 0,
      name: map['name'] as String? ?? '',
      mobileNumber: map['mobileNumber'] as String? ?? '',
      driverId: map['driverId'] as int? ?? 0,
      noOfChildren: map['noOfChildren'] as int? ?? 1,
      pendingFees: map['pendingFees'] as int? ?? 0,
      paymentIds: [],
    );
  }
}
