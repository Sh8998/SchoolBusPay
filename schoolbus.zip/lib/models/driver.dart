class Driver {
  final int id; // Unique ID
  final String name;
  final String busNo;
  final String mobileNumber;
  final List<int> parentIds;

  Driver({
    required this.id,
    required this.name,
    required this.busNo,
    required this.mobileNumber,
    this.parentIds = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != 0) 'id': id,
      'name': name,
      'busNo': busNo,
      'mobileNumber': mobileNumber,
      'parentIds': parentIds.join(','), // For SQLite
    };
  }

  factory Driver.fromMap(Map<String, dynamic> map) {
    final parentIdsStr = (map['parentIds'] ?? '').toString();
    final parsedParentIds = parentIdsStr.isNotEmpty
        ? parentIdsStr.split(',').map((e) => int.tryParse(e) ?? 0).toList()
        : [];

    return Driver(
      id: map['id'] as int? ?? 0,
      name: map['name'] as String? ?? '',
      busNo: map['busNo'] as String? ?? '',
      mobileNumber: map['mobileNumber'] as String? ?? '',
      parentIds: [],
    );
  }

  factory Driver.fromFirestore(Map<String, dynamic> map) {
    final parentIds = map['parentIds'] as List<dynamic>? ?? [];
    return Driver(
      id: map['id'] as int? ?? 0,
      name: map['name'] as String? ?? '',
      busNo: map['busNo'] as String? ?? '',
      mobileNumber: map['mobileNumber'] as String? ?? '',
      parentIds: parentIds.map((e) => e as int).toList(),
    );
  }
}
